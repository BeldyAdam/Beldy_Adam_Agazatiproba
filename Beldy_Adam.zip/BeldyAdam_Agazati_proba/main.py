#import szam
import korok
#szam.generalas()
lista = korok.bekeres()
masodik = korok.konzolra_ir(korok.elso_idos(lista))
korok.fajl_ir(masodik)