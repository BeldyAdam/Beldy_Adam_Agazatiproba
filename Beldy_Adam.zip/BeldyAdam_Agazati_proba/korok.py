def bekeres():
    lista = []
    for i in range(1, 6):
        kor = int(input(f"II/A\n\t{i}. Kérek egy számot 0-120 között: "))
        while not (kor >= 0 and kor <= 120):
            kor = int(input("Nem megfelelő intervallum, kérek egy másikat: "))
        lista.append(kor)
    print("II/A,B,C\n\t",lista)
    return lista

def elso_idos(lista):
    index = 0
    for i in range(len(lista)):
        if (lista[i] >= 70 and index == 0):
            index = i
    return index

def konzolra_ir(index):
    print(f"II/D,E\n\tElső idős ember korának helye a listában: {index+1}")
    return index

def fajl_ir(index):
    with open("oreg.txt", "w") as f:
        f.write(f"II/F\n\tElső idős ember korának helye a listában: {index+1}")