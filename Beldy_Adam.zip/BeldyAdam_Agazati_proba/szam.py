import random
def generalas():
    generalt_szam = random.randint(1, 50)
    print(f"I/A feladat:\n\tA generált szám: {generalt_szam}")
    if generalt_szam % 5 == 0:
        print("I/B\n\tA szám öttel osztható!")
    elif generalt_szam % 3 == 0:
        print("I/B\n\tA szám hárommal  osztható!")
    elif generalt_szam % 5 == 0 and generalt_szam % 3 == 0:
        print("I/B\n\tA szám öttel és hárommal is osztható!")